# Get your .apk — no coding, no Android Studio

This folder is a complete Android project. GitHub's free servers will
compile it into a real `.apk` file for you — you just upload and download.

## Steps

1. **Create a free GitHub account** at github.com (skip if you already have one).

2. **Create a new repository**: click the **+** top-right -> **New repository**.
   Name it anything, e.g. `smart-public-transport-app`. Leave everything
   else default -> **Create repository**.

3. **Upload this entire folder's contents**: on the new repo's page, click
   **"uploading an existing file"** (or Add file -> Upload files). Drag the
   whole extracted folder (everything inside this zip) into the browser
   window — Chrome and Edge will preserve the folder structure
   automatically. Make sure the `.github` folder comes along too (it may
   be hidden in your file explorer — if your OS hides it, enable "show
   hidden files" before dragging, or upload `.github/workflows/build.yml`
   separately into a `.github/workflows/` path using "Add file -> Create
   new file" and typing that path as the filename).

4. **Commit the files** (the green "Commit changes" button at the bottom).

5. **Go to the "Actions" tab** at the top of your repository. A workflow
   called **"Build APK"** should already be running (it starts
   automatically on upload). Wait 2-4 minutes for the green checkmark.

6. **Download your APK**: click into the finished run -> scroll down to
   **Artifacts** -> click **app-debug-apk** to download a zip. Inside it
   is `app-debug.apk` — your actual installable app.

7. **Install it**: copy `app-debug.apk` to your Android phone (via USB,
   email, Google Drive, whatever's easiest) and tap it to install. You
   may need to allow "Install from unknown sources" the first time —
   Android will prompt you for this automatically.

That's it — a real app, built by GitHub's servers, no local setup needed.

---

## Alternative: build it yourself in Android Studio

If you'd rather build it on your own computer (useful if you want to
make changes and test quickly), see the step-by-step visual guide and
instructions from earlier in our conversation — this same project folder
works directly in Android Studio too (File -> Open -> select this folder).

## Notes
- This app works fully offline — your HTML app is bundled inside it.
- Reports/searches reset when the app is closed (stored in memory only,
  same as the browser version). Ask me if you want permanent on-device
  storage added.
